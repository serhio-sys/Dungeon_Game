var obj = document.querySelector('.qwe')
obj.addEventListener("click", function(e) {
var model = document.querySelector('.user_model')
model.classList.toggle('active')
});